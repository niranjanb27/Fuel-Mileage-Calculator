const express = require('express');
const Mysql = require('Mysql');
const cors = require('cors');

const app = express();
const PORT = 2000;

// Middleware
app.use(cors());
app.use(express.json());

// Connect to MongoDB
mongoose.connect('mongodb+srv://<username>:<password>@cluster0.mongodb.net/mileageDB', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => console.log('Connected to MongoDB'))
  .catch(error => console.error('MongoDB connection error:', error));

// Schema and Model
const mileageSchema = new mongoose.Schema({
  distance: Number,
  fuel: Number,
  rate: Number,
  mileage: Number,
});

const Mileage = mongoose.model('Mileage', mileageSchema);

// Endpoint to store mileage calculation
app.post('/mileage', async (req, res) => {
  try {
    const mileageData = new Mileage(req.body);
    await mileageData.save();
    res.status(200).json({ message: 'Mileage data saved successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to save mileage data' });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
async function saveMileageData(distance, fuel, rate, mileage) {
    try {
      const response = await fetch('http://localhost:5000/mileage', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ distance, fuel, rate, mileage }),
      });
      const data = await response.json();
      console.log(data.message);
    } catch (error) {
      console.error('Error saving mileage data:', error);
    }
  }
  
  /*button.addEventListener('click', () => {
    const dis = parseInt(document.getElementById('dis').value);
    const fuel = parseInt(document.getElementById('fuel').value);
    const rate = parseInt(document.getElementById('rate').value);
    const result = document.getElementById('output');
  
    if (dis > 0 && fuel > 0) {
      const mileage = ((dis * rate) / fuel).toFixed(2);
      result.innerHTML = 'Your vehicle mileage is: ' + mileage;
      saveMileageData(dis, fuel, rate, parseFloat(mileage)); // Save data to MongoDB
    }
  });
  */